<?php
session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Accounts</title>
<link rel="icon" type="image/png" sizes="192x192" href="Logo/Logo.png">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Carlito&display=swap" rel="stylesheet">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body{
background-image: linear-gradient(#18392B,#435b4d);
background-repeat: none;
background-size: cover;
}
.login-container {
min-height: 100vh;
display: flex;
justify-content: center;
align-items: center;
}
.login-image {
width: 50%;
max-width: 300px;
display: block;
margin: 0 auto 20px;
}
.login-box {
padding: 2rem;
background: rgba(255, 255, 255, 0.3);
border-radius: 10px;
box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
}
.login_text{
    font-family: 'Carlito', sans-serif;
font-weight: 800;
}
.login_btn{
background-color: #18392B;
font-family: 'Carlito', sans-serif;
font-weight: 600;
color: white;
} 
.login_btn:hover{
background-color: rgba(67,91,77,0.5);
}
label{
font-family: 'Carlito', sans-serif;
font-weight: 700;
}
.remember_password{
font-family: 'Carlito', sans-serif;
font-weight: 500;
}
.t{
    font-family: 'Carlito', sans-serif;  
}
.forgotPassword{
color: black;
text-decoration: none;
font-family: 'Carlito', sans-serif;
font-weight: 500;
}
.forgotPassword:hover{
color: #18392B;
}
input{
font-family: 'Carlito', sans-serif;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row login-container">
<!-------------------------------session start-------------------------------------->
<div class="container mt-1">
<?php
if(isset($_SESSION['status'])){
?>
<div class="alert alert-info t alert-dismissible p-3 fade show">
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
<strong class="pr-2">Dear User!</strong><?php echo $_SESSION['status'];?>
</div>
<?php
unset($_SESSION['status']);
}
?>
</div>
<!-------------------------------------session end------------------------------->
<!-------------------------------session start-------------------------------------->
<div class="container mt-1">
<?php
if(isset($_SESSION['status11'])){
?>
<div class="alert alert-info t alert-dismissible p-3 fade show">
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
<strong class="pr-2">Dear User!</strong><?php echo $_SESSION['status11'];?>
</div>
<?php
unset($_SESSION['status11']);
}
?>
</div>
<!-------------------------------------session end------------------------------->    
<div class="col-md-6 col-lg-4 col-sm-12 mx-auto">
<div class="login-box">
<img src="Logo/LogoTrensparent.png" alt="Login Image" class="login-image">

<form class="marg" action="SqlVerifyPass.php" method="post">
<div class="mb-3">
<label class="form-label">Add Otp Code</label>
<input type="text" class="form-control" placeholder="Add Otp Code" name="OTP">
</div>
<div class="mb-3">
<label for="password" class="form-label">Password</label>
<input type="password" class="form-control" name="UserPassword" placeholder="User password">
</div>
<button type="submit" class="btn login_btn w-100">Verify</button>
</form>

</div><!--login-boxs-->
</div><!--cols-->
</div><!--login-container-->
</div><!--container-fluid-->
</body>

</html>