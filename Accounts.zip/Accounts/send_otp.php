<?php
session_start();
include 'Connection/connect.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Attempt to open connection
$conn = OpenConnection();

// Check if connection is successful
if ($conn) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $Email = $_POST['Email'];

        // Check if the email exists in the database
        $sql = "SELECT * FROM Users WHERE Email = ?";
        $params = array($Email);
        $stmt = sqlsrv_query($conn, $sql, $params);

        if ($stmt === false) {
            die(print_r(sqlsrv_errors(), true)); // Error handling
        }

        if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            // Generate a random OTP
            $otp = rand(100000, 999999);
            
            // Set the OTP expiry time to 10 minutes from now
            $otpExpiry = date('Y-m-d H:i:s', strtotime('+10 minutes'));

            // Update the database with OTP and OTP expiry
            $updateSql = "UPDATE Users SET OTP = ?, OTPVerify = ? WHERE Email = ?";
            $updateParams = array($otp, $otpExpiry, $Email);
            $updateStmt = sqlsrv_query($conn, $updateSql, $updateParams);

            if ($updateStmt === false) {
                die(print_r(sqlsrv_errors(), true)); // Error handling
            }

            // Send email with OTP and OTP expiry
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'college@gmail.com'; // Use your Gmail username
            $mail->Password = '123'; // Use your Gmail password
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->setFrom('college@gmail.com');
            $mail->addAddress($Email);
            $mail->Subject = 'Password Reset OTP';
            $mail->Body = 'Your OTP is: ' . $otp . '. This OTP is valid until: ' . $otpExpiry;
            
            if ($mail->send()) {
                $_SESSION['status'] = 'OTP sent successfully. Check your email.';
                header("Location: verify_otp.php"); // Redirect to OTP verification page
                exit();
            } else {
                $_SESSION['status'] = 'Error sending OTP: ' . $mail->ErrorInfo;
                header("Location: ResetPass.php"); // Redirect back to password reset page
                exit();
            }
        } else {
            $_SESSION['status'] = "Email not found in the database!";
            header("Location: ResetPass.php"); // Redirect back to password reset page
            exit();
        }
    }
    sqlsrv_close($conn);
}
?>
