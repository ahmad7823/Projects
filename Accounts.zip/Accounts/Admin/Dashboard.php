<?php
session_start();
include '../Connection/connect.php';
$conn = OpenConnection();
if (!$conn) die("Connection failed.");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accounts</title>
    <link rel="icon" type="image/png" sizes="192x192" href="../Logo/accounts-favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Nunito', sans-serif; background-color: #f4f4f4; margin: 0; }
        .header { height: 60px; background: #fff; box-shadow: 0 2px 6px rgba(0,0,0,0.1); padding: 0 20px; display: flex; justify-content: space-between; align-items: center; }
        .header .menu-icon { font-size: 24px; cursor: pointer; }
        /* .header .user-img img { border-radius: 50%; height: 40px; width: 40px; } */
        
        .user-img img {
            border-radius: 50%;
            border: 2px solid #ccc;
        }
        .nk-sidebar { width: 250px; background: #fff; position: fixed; height: 100%; overflow-y: auto; transition: all 0.3s ease; box-shadow: 2px 0 6px rgba(0,0,0,0.1); }
        .nk-nav-scroll { padding: 20px 0; }
        .logo-compact { background-color: #5a52d1; color: #fff; font-size: 22px; text-align: center; padding: 18px 0; font-weight: bold; }
        .metismenu { list-style: none; padding: 0; margin: 0; }
        .metismenu li { padding: 0; }
        .metismenu a { color: #333; display: block; padding: 10px 20px; text-decoration: none; transition: all 0.3s; }
        .metismenu a:hover, .metismenu .active > a { background-color: #5a52d1; color: #fff; }
        .submenu { display: none; padding-left: 20px; background: #f9f9f9; }
        ul.metismenu, ul.submenu, ul.metismenu li, ul.submenu li { list-style: none; padding-left: 0; margin: 0; }
        .submenu.open { display: block; }
        .has-arrow::after { content: "\f105"; font-family: "Font Awesome 6 Free"; font-weight: 900; float: right; }
        #main-wrapper { margin-left: 250px; padding: 20px; }
        .dashboard-title { font-size: 28px; font-weight: 700; margin-bottom: 30px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        .card h5 { font-weight: 600; }
        @media(max-width: 768px) {
            .nk-sidebar { transform: translateX(-250px); z-index: 1000; }
            .nk-sidebar.active { transform: translateX(0); }
            #main-wrapper { margin-left: 0; padding: 10px; }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="nk-sidebar" id="sidebar">
    <div class="logo-compact">Accounts</div>
    <div class="nk-nav-scroll">
        <ul class="metismenu" id="menu">
            <li><a href="Dashboard.php"><i class="fa-solid fa-house-laptop"></i> Dashboard</a></li>
            <li class="nav-label px-3 mt-3 text-muted text-uppercase">Setup</li>
            <li>
                <a class="has-arrow" href="javascript:void(0);"><i class="fa fa-gear"></i> Setup</a>
                <ul class="submenu">
                    <li><a href="ViewStudentFee.php">Student Fee</a></li>
                    <li><a href="ViewFeeTransactions.php">Fee Transactions</a></li>
                    <li><a href="ViewFeeStructure.php">Fee Structure</a></li>
                    <li><a href="ViewUtilityBills.php">Utility Bills</a></li>
                    <li><a href="ViewEmployeeSalaries.php">Employee Salaries</a></li>
                    <li><a href="ViewSalaryPayments.php">Salary Payments</a></li>
                    <li><a href="ViewVendors.php">Vendors</a></li>
                    <li><a href="ViewVendorPayments.php">Vendor Payments</a></li>
                    <li><a href="ViewBudgetTracking.php">Budget Tracking</a></li>
                </ul>
            </li>
            <li>
        <a class="has-arrow" href="#"><i class="fa fa-chart-line"></i> <span class="nav-text" style="color: #000;">Operation</span></a>
        <ul class="submenu">
            <li><a href="Invoice.php">Invoice</a></li>
            <li><a href="ViewPayment.php">Payment</a></li>
        </ul>
            </li>
        </ul>
    </div>
</div>

<!-- Header -->
<div class="header">
    <div class="header-left">
        <i class="fas fa-bars menu-icon" id="toggleSidebar" style="color: #000; margin-left: 265px;"></i>
    </div>
    <!-- <div class="user-img">
        <img src="images/user/User_Img.png" alt="User">
    </div> -->
     <li class="icons dropdown">
                    <div class="user-img c-pointer position-relative" style="margin-top: -30px;">
                        <span class="activity active"></span>
                        <img src="images/user/User_Img.png" height="40" width="40" alt="" />
                    </div>
                    <div class="dropdown-profile">
                        <div class="dropdown-content-body">
                            <ul>
                                <!-- <li><a href="LoginForm.php"><i class="fa fa-key"></i> <span>Logout</span></a></li> -->
                                <li><a href="Logout.php" style="color: #000; text-decoration: none;"><i class="fa fa-key"></i> <span>Logout</span></a></li>
                            </ul>
                        </div>
                    </div>
                </li>
</div>

<!-- Main Content -->
<div id="main-wrapper">
    <div class="container-fluid">
        <h2 class="dashboard-title">Dashboard</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card p-4">
                    <h5>Total Students</h5>
                    <p class="fs-4 fw-bold text-primary">123</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4">
                    <h5>Total Revenue</h5>
                    <p class="fs-4 fw-bold text-success">PKR 500,000</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4">
                    <h5>Pending Fees</h5>
                    <p class="fs-4 fw-bold text-danger">PKR 75,000</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const userImg = document.querySelector(".user-img");
    const dropdownProfile = document.querySelector(".dropdown-profile");

    // Initially hide the dropdown
    dropdownProfile.style.display = "none";

    // Toggle dropdown on click
    userImg.addEventListener("click", function () {
        if (dropdownProfile.style.display === "none") {
            dropdownProfile.style.display = "block";
        } else {
            dropdownProfile.style.display = "none";
        }
    });

    // Optional: Hide when clicking outside
    document.addEventListener("click", function (e) {
        if (!userImg.contains(e.target) && !dropdownProfile.contains(e.target)) {
            dropdownProfile.style.display = "none";
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const notificationIcon = document.querySelector(".notification-icon");
    const dropdown = document.querySelector(".drop-down");

    // Initially hide the dropdown
    dropdown.style.display = "none";

    // Toggle dropdown on bell icon click
    notificationIcon.addEventListener("click", function (e) {
        e.stopPropagation(); // Prevent click from bubbling up
        dropdown.style.display = (dropdown.style.display === "none") ? "block" : "none";
    });

    // Optional: Hide dropdown when clicking outside
    document.addEventListener("click", function (e) {
        if (!dropdown.contains(e.target) && !notificationIcon.contains(e.target)) {
            dropdown.style.display = "none";
        }
    });
});

</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const menuItems = document.querySelectorAll(".has-arrow");

        menuItems.forEach(item => {
            item.addEventListener("click", function (e) {
                e.preventDefault(); // Prevent default anchor behavior
                const submenu = this.nextElementSibling;

                if (submenu && submenu.classList.contains("submenu")) {
                    submenu.classList.toggle("open");
                }
            });
        });
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggleBtn = document.getElementById("mobile-menu-toggle");
        const sidebar = document.getElementById("sidebar");

        toggleBtn.addEventListener("click", function () {
            sidebar.classList.toggle("sidebar-open");
        });
    });
</script>

<script>
    function toggleSidebar() {
        const sidebar = document.getElementById("sidebar");
        sidebar.classList.toggle("sidebar-hidden");
    }
</script>

</body>
</html>
