<?php
// invoice.php
// Usage: invoice.php?InvoiceNo=INV-001

session_start();
include '../Connection/connect.php'; // your SQL Server connection file
$conn = OpenConnection();
if (!$conn) die("Database connection failed.");

// Load FPDF
require('fpdf/GenerateInvoicePdf.php');

// Get InvoiceNo from URL
if (!isset($_GET['InvoiceNo']) || empty($_GET['InvoiceNo'])) {
    die("❌ InvoiceNo parameter is missing.");
}
$invoiceNo = $_GET['InvoiceNo'];

// Fetch VendorPayments record
$sql = "SELECT PaymentID, VendorID, InvoiceNo, AmountPaid, PaymentDate, PaymentMode, Remarks
        FROM VendorPayments
        WHERE InvoiceNo = ?";
$params = array($invoiceNo);
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if (!$data) {
    die("❌ No record found for InvoiceNo: $invoiceNo");
}

// Format date
$paymentDate = $data['PaymentDate'] instanceof DateTime
    ? $data['PaymentDate']->format('Y-m-d')
    : $data['PaymentDate'];

// Create PDF
class PDF extends FPDF {
    function Header() {
        // Company Name
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'Vendor Payment Invoice', 0, 1, 'C');
        $this->Ln(5);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page '.$this->PageNo().'/{nb}', 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

// Invoice Details
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(50, 10, 'Invoice No:', 0, 0);
$pdf->Cell(50, 10, $data['InvoiceNo'], 0, 1);
$pdf->Cell(50, 10, 'Payment ID:', 0, 0);
$pdf->Cell(50, 10, $data['PaymentID'], 0, 1);
$pdf->Cell(50, 10, 'Vendor ID:', 0, 0);
$pdf->Cell(50, 10, $data['VendorID'], 0, 1);
$pdf->Cell(50, 10, 'Amount Paid:', 0, 0);
$pdf->Cell(50, 10, number_format($data['AmountPaid'], 2), 0, 1);
$pdf->Cell(50, 10, 'Payment Date:', 0, 0);
$pdf->Cell(50, 10, $paymentDate, 0, 1);
$pdf->Cell(50, 10, 'Payment Mode:', 0, 0);
$pdf->Cell(50, 10, $data['PaymentMode'], 0, 1);
$pdf->Cell(50, 10, 'Remarks:', 0, 0);
$pdf->Cell(50, 10, $data['Remarks'], 0, 1);

$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Thank you for your payment!', 0, 1, 'C');

// Output PDF in browser
$pdf->Output('I', 'Invoice_'.$data['InvoiceNo'].'.pdf');
?>
