<?php
require('../fpdf/fpdf.php');

// Start output buffering to prevent premature output
ob_start();

// === Database Connection ===
// $serverName = "DESKTOP-FUGQNF4\\MSSQLSERVER2014";
// $connectionOptions = array(
//     "Database" => "Accounts",
//     "Uid" => "sa",
//     "PWD" => "12345"
// );
// $conn = sqlsrv_connect($serverName, $connectionOptions);
// if (!$conn) {
//     die(print_r(sqlsrv_errors(), true));
// }

session_start();
// include './Connection/connect.php';
include '../../Connection/connect.php';

$conn = OpenConnection();
if (!$conn) die("Database connection failed.");

// === Get Invoice ID from URL ===
if (!isset($_GET['ID'])) {
    die("Error: No Invoice ID provided in the URL (e.g., ?ID=INV-002)");
}
$invoiceNo = $_GET['ID'];

// === Fetch Invoice Data ===
$sql = "SELECT * FROM VendorPayments WHERE InvoiceNo = ?";
$stmt = sqlsrv_query($conn, $sql, array($invoiceNo));
if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}
$invoiceData = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if (!$invoiceData) {
    die("Error: Invoice not found.");
}
sqlsrv_free_stmt($stmt);

// === Extend FPDF with Header/Footer ===
class PDF extends FPDF {
    function Header() {
        // 
        $this->Image('../fpdf/Logo/accounts-favicon.png', 10, 8, 20);
        $this->SetFont('Arial', 'B', 20);
        $this->Cell(0, 10, 'Accounts & Billing Services', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 16);
        $this->SetTextColor(91, 44, 111);
        $this->Cell(0, 10, 'INVOICE', 0, 1, 'C');
        $this->SetTextColor(0);
        $this->Ln(5);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page '.$this->PageNo().'/{nb}', 0, 0, 'C');
    }
}

// === Start PDF Generation ===
$pdf = new PDF('P', 'mm', 'A4');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// === Format Dates ===
$PaymentDate = isset($invoiceData['PaymentDate']) && $invoiceData['PaymentDate'] instanceof DateTime ? $invoiceData['PaymentDate']->format('d-m-Y') : '';
$InvoiceDate = date('d-m-Y'); // Always today's date
$PaymentMode = isset($invoiceData['PaymentMode']) ? $invoiceData['PaymentMode'] : '';
$fromDate = isset($invoiceData['FromDate']) && $invoiceData['FromDate'] instanceof DateTime ? $invoiceData['FromDate']->format('d-m-Y') : '';
$toDate = isset($invoiceData['ToDate']) && $invoiceData['ToDate'] instanceof DateTime ? $invoiceData['ToDate']->format('d-m-Y') : '';

// === Invoice & Booking Details ===
$pdf->SetFillColor(230, 230, 230);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'Invoice & Vendor Payments Details', 1, 1, 'L', true);
$pdf->SetFont('Arial', '', 11);

$pdf->Cell(95, 8, 'Invoice No: ' . htmlspecialchars($invoiceData['InvoiceNo'] ?? ''), 1, 0, 'L');
$pdf->Cell(95, 8, 'Payment Date: ' . $PaymentDate, 1, 1, 'L');

$pdf->Cell(95, 8, 'Vendor ID: ' . htmlspecialchars($invoiceData['VendorID'] ?? ''), 1, 0, 'L');
$pdf->Cell(95, 8, 'Payment ID: ' . htmlspecialchars($invoiceData['PaymentID'] ?? ''), 1, 1, 'L');

$pdf->Cell(95, 8, 'From Date: ' . $fromDate, 1, 0, 'L');
$pdf->Cell(95, 8, 'To Date: ' . $toDate, 1, 1, 'L');

$pdf->Cell(95, 8, 'Payment Mode: ' . $PaymentMode, 1, 0, 'L');
$pdf->Cell(95, 8, 'Invoice Date: ' . $InvoiceDate, 1, 1, 'L');
$pdf->Ln(5);

// === Item Table ===
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(200, 220, 255);
$pdf->Cell(10, 10, "Sr#", 1, 0, "C", true);
$pdf->Cell(45, 10, "Invoice No", 1, 0, "C", true);
$pdf->Cell(45, 10, "From Date", 1, 0, "C", true);
$pdf->Cell(45, 10, "To Date", 1, 0, "C", true);
$pdf->Cell(45, 10, "Amount", 1, 1, "C", true);

$pdf->SetFont('Arial', '', 11);
$pdf->SetFillColor(224, 235, 255);

$pdf->Cell(10, 8, '1', 1, 0, "C");
$pdf->Cell(45, 8, htmlspecialchars($invoiceData['InvoiceNo'] ?? ''), 1, 0, "C"); // Corrected: Use $invoiceData['InvoiceNo']
$pdf->Cell(45, 8, $fromDate, 1, 0, 'C');
$pdf->Cell(45, 8, $toDate, 1, 0, 'C');
$pdf->Cell(45, 8, number_format((float)($invoiceData['Amount'] ?? 0), 2), 1, 1, 'R');
$pdf->Ln(5);

// === Financial Summary ===
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(230, 230, 230);
$pdf->Cell(0, 8, 'Financial Summary', 1, 1, 'L', true);
$pdf->SetFont('Arial', '', 11);

$pdf->Cell(140, 8, 'Subtotal:', 1, 0, 'R');
$pdf->Cell(50, 8, number_format((float)($invoiceData['Amount'] ?? 0), 2), 1, 1, 'R');

$pdf->Cell(140, 8, 'Budget Amount:', 1, 0, 'R');
$pdf->Cell(50, 8, number_format((float)($invoiceData['BudgetAmount'] ?? 0), 2), 1, 1, 'R');

$pdf->Cell(140, 8, 'Used Amount:', 1, 0, 'R');
$pdf->Cell(50, 8, number_format((float)($invoiceData['UsedAmount'] ?? 0), 2), 1, 1, 'R');

$pdf->Cell(140, 8, 'Remaining Amount:', 1, 0, 'R');
// Calculate Remaining Amount: BudgetAmount - UsedAmount
$remainingAmount = ((float)($invoiceData['BudgetAmount'] ?? 0)) - ((float)($invoiceData['UsedAmount'] ?? 0));
$pdf->Cell(50, 8, number_format($remainingAmount, 2), 1, 1, 'R'); // Corrected calculation
$pdf->Ln(5);

// === Status Information ===
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'Status Information', 1, 1, 'L', true);
$pdf->SetFont('Arial', '', 11);

$pdf->Cell(95, 8, 'Payment Status: ' . htmlspecialchars($invoiceData['PaymentStatus'] ?? ''), 1, 0, 'L');
$pdf->Cell(95, 8, 'Invoice Status: ' . (!empty($invoiceData['InvoiceStatus']) ? htmlspecialchars($invoiceData['InvoiceStatus']) : 'Pending'), 1, 1, 'L');
$pdf->Ln(5);

// === Footer Notes ===
$pdf->SetFont('Arial', 'I', 10);
$pdf->SetTextColor(100);
$pdf->Cell(0, 5, "Payment Terms: " . htmlspecialchars($invoiceData['PaymentTerms'] ?? ''), 0, 1, 'L');
$pdf->Cell(0, 5, "Email Sent: " . htmlspecialchars($invoiceData['EmailSent'] ?? ''), 0, 1, 'L');
$pdf->Cell(0, 5, "Thank you!", 0, 1, 'C');

// === Clean Output Buffer ===
if (ob_get_length()) ob_end_clean();

// === Output PDF ===
$pdf->Output('I', 'Invoice-' . htmlspecialchars($invoiceData['InvoiceNo'] ?? 'UNKNOWN') . '.pdf');
?>