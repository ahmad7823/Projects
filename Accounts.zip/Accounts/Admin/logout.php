<?php
include 'session.php';
session_destroy();

// Assuming $uemail is defined elsewhere in your code
$UserName = $_SESSION['UserName'];

echo "<script> window.location.assign('../index.php');</script>";
?>
