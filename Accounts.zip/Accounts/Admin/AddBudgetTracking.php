<?php
session_start();
include '../Connection/connect.php';
$conn = OpenConnection();
if (!$conn) die("Connection failed.");

// Auto-generate CategoryID
function generateCategoryID($conn) {
    $query = "SELECT TOP 1 CategoryID FROM BudgetTracking WHERE CategoryID LIKE 'CID-%' ORDER BY CategoryID DESC";
    $stmt = sqlsrv_query($conn, $query);
    $lastID = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    if ($lastID) {
        $num = (int) str_replace('CID-', '', $lastID['CategoryID']);
        $num++;
        return "CID-" . str_pad($num, 3, "0", STR_PAD_LEFT);
    }
    return "CID-001";
}

// Auto-generate BudgetID
function generateBudgetID($conn) {
    $query = "SELECT TOP 1 BudgetID FROM BudgetTracking WHERE BudgetID LIKE 'BID-%' ORDER BY BudgetID DESC";
    $stmt = sqlsrv_query($conn, $query);
    $lastID = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    if ($lastID) {
        $num = (int) str_replace('BID-', '', $lastID['BudgetID']);
        $num++;
        return "BID-" . str_pad($num, 3, "0", STR_PAD_LEFT);
    }
    return "BID-001";
}

// Initialize form
$budget = [
    'CategoryID' => generateCategoryID($conn),
    'BudgetID' => '',
    'Remarks' => '',
    'BudgetAmount' => '',
    'UsedAmount' => '',
    'RemainingAmount' => '',
    'MonthYear' => ''
];

// Edit Mode
if (isset($_GET['edit'])) {
    $CategoryID = $_GET['edit'];
    $stmt = sqlsrv_query($conn, "SELECT * FROM BudgetTracking WHERE CategoryID = ?", [$CategoryID]);
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $budget = $row;
    }
}

// Handle Insert
if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_POST['is_edit'])) {
    $CategoryID = generateCategoryID($conn);
    $BudgetID = generateBudgetID($conn);
    $Remarks = $_POST['Remarks'];
    $BudgetAmount = $_POST['BudgetAmount'];
    $UsedAmount = $_POST['UsedAmount'];
    $RemainingAmount = $_POST['RemainingAmount'];
    $MonthYearRaw = $_POST['MonthYear'];

    // Save as YYYY-MM
    $MonthYear = date('Y-m', strtotime($MonthYearRaw));

    $query = "INSERT INTO BudgetTracking 
              (CategoryID, BudgetID, Remarks, BudgetAmount, UsedAmount, RemainingAmount, MonthYear)
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $params = [$CategoryID, $BudgetID, $Remarks, $BudgetAmount, $UsedAmount, $RemainingAmount, $MonthYear];
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt) {
        echo "<script>alert('Record is saved successfully!'); window.location.href='ViewBudgetTracking.php';</script>";
        exit;
    } else {
        die(print_r(sqlsrv_errors(), true));
    }
}

// Handle Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['is_edit'])) {
    $CategoryID = $_POST['CategoryID'];
    $Remarks = $_POST['Remarks'];
    $BudgetAmount = $_POST['BudgetAmount'];
    $UsedAmount = $_POST['UsedAmount'];
    $RemainingAmount = $_POST['RemainingAmount'];
    $MonthYear = date('Y-m', strtotime($_POST['MonthYear']));

    $query = "UPDATE BudgetTracking 
              SET Remarks=?, BudgetAmount=?, UsedAmount=?, RemainingAmount=?, MonthYear=? 
              WHERE CategoryID=?";
    $params = [$Remarks, $BudgetAmount, $UsedAmount, $RemainingAmount, $MonthYear, $CategoryID];
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt) {
        echo "<script>alert('Record is updated successfully!'); window.location.href='ViewBudgetTracking.php';</script>";
        exit;
    } else {
        die(print_r(sqlsrv_errors(), true));
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png" sizes="192x192" href="../Logo/accounts-favicon.png">
    <title>Accounts</title>
     <meta charset="UTF-8">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"> -->
     
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">

 <!-- jQuery (Required first) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery (only one version) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Google Charts -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Font Awesome (only one latest version) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            background: #f8f9fa;
        }
        .card {
            border-radius: 10px;
        }
        .form-control {
            border-radius: 8px;
        }
        .btn {
            border-radius: 6px;
        }
        h2 {
            font-weight: bold;
            color: #343a40;
        }

         * {
            margin: 0;
            padding: 0;
        }

          body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f4f4;
        }

        /* Header Styling */
        .header {
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
            width: 100%;
        }

        .header-left .input-group {
            display: flex;
            align-items: center;
        }

    .header-right {
    position: relative;
        }

    .notification-icon {
    color: #333;
    font-size: 18px;
    position: relative;
    display: inline-block;
    padding: 10px;
    text-decoration: none;
}

    .notification-icon .badge {
    position: absolute;
    top: 6px;
    right: 6px;
    background-color: red;
    color: white;
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 50%;
}

    .drop-down {
    background: #fff;
    position: absolute;
    top: 40px;
    right: 0;
    min-width: 250px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    display: none;
    z-index: 99;
    overflow: hidden;
}

    .dropdown:hover .drop-down {
    display: block;
}

    .dropdown-header {
    background-color: #f5f5f5;
    padding: 10px 15px;
    font-weight: bold;
    border-bottom: 1px solid #ddd;
}

    .dropdown-content-body {
    padding: 10px;
}

    .notification-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

    .notification-list li {
    margin-bottom: 10px;
}

    .notification-list li a {
    text-decoration: none;
    color: #333;
    display: block;
    padding: 8px 10px;
    border-radius: 4px;
    transition: background 0.3s;
}

    .notification-list li a:hover {
    background-color: #f0f0f0;
}

        /* Sidebar Styling */
        .nk-sidebar {
            width: 250px;
            /* width: 15%; */
            /* background-color: #fff;
            color: #000; */
            background-color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            margin: 0;
            padding: 0;
            /* overflow-y: auto; */
            /* padding-top: 60px; */
        }

        /* Default: hide sidebar on small screens */
        .sidebar {
        transition: all 0.3s ease;
        transform: translateX(-250px); /* hide left */
        }

       /* When open: show sidebar */
       .sidebar.sidebar-open {
       transform: translateX(0);
       }

        .nk-nav-scroll {
            padding: 15px;
        }

        /* .nav-header {
            background-color: #fff;
            padding: 15px;
            color: white;
            display: flex;
            align-items: center;
        } */

        .brand-logo a {
            text-decoration: none;
            color: white;
            font-size: 22px;
            font-weight: bold;
        }

        .metismenu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .metismenu li {
            margin-bottom: 10px;
        }

        .metismenu a {
            color: #000;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-radius: 6px;
        }

        .submenu {
        display: none;
        padding-left: 20px;
        }

       .submenu.open {
       display: block;
        }

        .metismenu a:hover,
        .metismenu .active > a {
            background-color: #5a52d1;
        }

        .nav-label {
            color: #ddd;
            margin: 10px 15px;
            font-weight: bold;
        }

        .has-arrow::after {
            content: "\f107";
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            float: right;
        }

        .drop-down {
            background: #fff;
            position: absolute;
            top: 40px;
            right: 0;
            min-width: 250px;
            border: 1px solid #ddd;
            border-radius: 5px;
            display: none;
            z-index: 99;
        }

        .dropdown:hover .drop-down {
            display: block;
        }

        .user-img img {
            border-radius: 50%;
            border: 2px solid #ccc;
        }

        .activity {
            width: 10px;
            height: 10px;
            background: green;
            border-radius: 50%;
            position: absolute;
            top: 0;
            right: 0;
        }

        .dropdown-profile {
            position: absolute;
            top: 45px;
            right: 0;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            display: none;
            min-width: 200px;
            z-index: 99;
        }

        .icons.dropdown:hover .dropdown-profile {
            display: block;
        }

        .dropdown-content-body ul {
            list-style: none;
            margin: 0;
            padding: 10px;
        }

        .dropdown-content-body ul li {
            list-style: none;
        }

        ul li {
            list-style: none !important;
        }

        .dropdown-content-body ul li a {
            display: block;
            padding: 8px;
            color: #333;
            text-decoration: none;
            border-radius: 4px;
        }

        .dropdown-content-body ul li a:hover {
            background-color: #eee;
        }

        /* Content Wrapper */
        #main-wrapper {
            margin-left: 250px;
        }

        .btn_save {
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            padding: 8px 20px;
            border: none;
        }
        .text_colors {
            color: white;
        }
    </style>

</head>
<body>
    <!--**********************************
Main wrapper start
***********************************-->
<!--  -->

<div id="main-wrapper">
    <div class="nav-header">
        <div class="brand-logo">
            <a href="#">
                <!-- <b class="logo-abbr">B</b> -->
                
            </a>
        </div>
    </div>

    <div class="header" id="header">
        <div class="sidebar-show-sidebar">
              <div class="header-left">
    <div class="input-group icons">
        <i class="fas fa-bars menu-icon" onclick="toggleSidebar()" style="color: #000;"></i>
    </div>
    </div>

        </div>

                <li class="icons dropdown">
                    <div class="user-img c-pointer position-relative" style="margin-top: -30px;">
                        <span class="activity active"></span>
                        <img src="images/user/User_Img.png" height="40" width="40" alt="" />
                    </div>
                    <div class="dropdown-profile">
                        <div class="dropdown-content-body">
                            <ul>
                                <!-- <li><a href="LoginForm.php"><i class="fa fa-key"></i> <span>Logout</span></a></li> -->
                                <li><a href="Logout.php"><i class="fa fa-key"></i> <span>Logout</span></a></li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    </div>

    <!-- Sidebar -->
    <div class="nk-sidebar">
        <div class="nk-nav-scroll">
            <span class="logo-compact" style="background-color: #5a52d1; color: #fff; font-size: 22px; display: block; padding: 18px 30px; text-decoration: none; width: 250px; height: 7vh; margin-left: -15px; margin-top: -20px; margin-bottom: 30px;">Accounts</span>
            <ul class="metismenu" id="menu">
                <li><a href="Dashboard.php"><i class="fa-solid fa-house-laptop"></i> <span class="nav-text">Dashboard</span></a></li>
                <li class="nav-label" style="text-transform: uppercase; color: #000;">Setup</li>
            <ul>
    <li>
        <a class="has-arrow" href="#"><i class="fa fa-gear"></i> <span class="nav-text">Setup</span></a>
        <ul class="submenu">
            <li><a href="ViewStudentFee.php">Student Fee</a></li>
            <li><a href="ViewFeeTransactions.php">Fee Transactions</a></li>
            <li><a href="ViewFeeStructure.php">Fee Structure</a></li>
            <li><a href="ViewUtilityBills.php">Utility Bills</a></li>
            <li><a href="ViewEmployeeSalaries.php">Employee Salaries</a></li>
            <li><a href="ViewSalaryPayments.php">Salary Payments</a></li>
            <li><a href="ViewVendors.php">Vendors</a></li>
            <li><a href="ViewVendorPayments.php">Vendor Payments</a></li>
            <li><a href="ViewBudgetTracking.php">Budget Tracking</a></li>
        </ul>
    </li>
         <li>
        <a class="has-arrow" href="#"><i class="fa fa-chart-line"></i> <span class="nav-text" style="color: #000;">Operation</span></a>
        <ul class="submenu">
            <li><a href="Invoice.php">Invoice</a></li>
            <li><a href="ViewPayment.php">Payment</a></li>
        </ul>
            </li>

    
</ul>
        </div>
    </div>
<div class="container mt-5">
    <div class="card">
        <div class="card-header bg-primary text-white">Add Budget</div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="is_edit" value="<?= isset($_GET['edit']) ? 1 : '' ?>">
                <div class="mb-3">
                    <label>Category ID</label>
                    <input type="text" name="CategoryID" class="form-control" readonly value="<?= htmlspecialchars($budget['CategoryID']) ?>">
                </div>
                <div class="mb-3">
                    <label>Budget Amount</label>
                    <input type="number" name="BudgetAmount" class="form-control" value="<?= htmlspecialchars($budget['BudgetAmount']) ?>" required>
                </div>
                <div class="mb-3">
                    <label>Used Amount</label>
                    <input type="number" name="UsedAmount" class="form-control" value="<?= htmlspecialchars($budget['UsedAmount']) ?>" required>
                </div>
                <div class="mb-3">
                    <label>Remaining Amount</label>
                    <input type="number" name="RemainingAmount" class="form-control" value="<?= htmlspecialchars($budget['RemainingAmount']) ?>" required>
                </div>
                <div class="mb-3">
                    <label>Month-Year</label>
                    <input type="month" name="MonthYear" class="form-control" value="<?= is_string($budget['MonthYear']) ? date('Y-m', strtotime($budget['MonthYear'])) : '' ?>" required>
                </div>
                <div class="mb-3">
                    <label>Remarks</label>
                    <input type="text" name="Remarks" class="form-control" value="<?= htmlspecialchars($budget['Remarks']) ?>" required>
                </div>
                <button type="submit" class="btn btn-success">Save</button>
                <a href="ViewBudgetTracking.php" class="btn btn-secondary">View</a>
            </form>
        </div>
    </div>
</div>

 <script>
    document.addEventListener("DOMContentLoaded", function () {
    const userImg = document.querySelector(".user-img");
    const dropdownProfile = document.querySelector(".dropdown-profile");

    // Initially hide the dropdown
    dropdownProfile.style.display = "none";

    // Toggle dropdown on click
    userImg.addEventListener("click", function () {
        if (dropdownProfile.style.display === "none") {
            dropdownProfile.style.display = "block";
        } else {
            dropdownProfile.style.display = "none";
        }
    });

    // Optional: Hide when clicking outside
    document.addEventListener("click", function (e) {
        if (!userImg.contains(e.target) && !dropdownProfile.contains(e.target)) {
            dropdownProfile.style.display = "none";
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const notificationIcon = document.querySelector(".notification-icon");
    const dropdown = document.querySelector(".drop-down");

    // Initially hide the dropdown
    dropdown.style.display = "none";

    // Toggle dropdown on bell icon click
    notificationIcon.addEventListener("click", function (e) {
        e.stopPropagation(); // Prevent click from bubbling up
        dropdown.style.display = (dropdown.style.display === "none") ? "block" : "none";
    });

    // Optional: Hide dropdown when clicking outside
    document.addEventListener("click", function (e) {
        if (!dropdown.contains(e.target) && !notificationIcon.contains(e.target)) {
            dropdown.style.display = "none";
        }
    });
});

</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const menuItems = document.querySelectorAll(".has-arrow");

        menuItems.forEach(item => {
            item.addEventListener("click", function (e) {
                e.preventDefault(); // Prevent default anchor behavior
                const submenu = this.nextElementSibling;

                if (submenu && submenu.classList.contains("submenu")) {
                    submenu.classList.toggle("open");
                }
            });
        });
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggleBtn = document.getElementById("mobile-menu-toggle");
        const sidebar = document.getElementById("sidebar");

        toggleBtn.addEventListener("click", function () {
            sidebar.classList.toggle("sidebar-open");
        });
    });
</script>

<script>
    function toggleSidebar() {
        const sidebar = document.getElementById("sidebar");
        sidebar.classList.toggle("sidebar-hidden");
    }
</script>

</body>
</html>
