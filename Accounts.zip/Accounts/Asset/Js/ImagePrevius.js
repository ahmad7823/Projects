function previewImages(event) {
    var files = event.target.files;
    var preview = document.getElementById('image-preview');
    
    preview.innerHTML = ''; // Clear previous previews
    
    for (var i = 0; i < files.length; i++) {
        var file = files[i];
        var reader = new FileReader();
        
        reader.onload = function(e) {
            var image = document.createElement('img');
            image.src = e.target.result;
            image.style.maxWidth = '600px'; // Limit preview size
            preview.appendChild(image);
        };
        
        reader.readAsDataURL(file);
    }
}