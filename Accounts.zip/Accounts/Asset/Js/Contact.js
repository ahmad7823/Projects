
$(document).ready(function() {
    var input = document.querySelector("#phone-number");
    var iti = window.intlTelInput(input, {
        separateDialCode: true,
        preferredCountries: ["sa","pk","us", "gb", "de", "fr", "es"], // Add your preferred countries here
        nationalMode: false,
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/utils.js"
    });

    input.addEventListener("input", function() {
        var countryCode = iti.getSelectedCountryData().dialCode;
        var flagIcon = iti.getSelectedCountryData().iso2;
        if (countryCode && flagIcon) {
            if (input.value.startsWith("+" + countryCode + " ")) {
                input.value = "+" + countryCode + " " + input.value.slice(("+" + countryCode + " ").length);
            } else {
                input.value = "+" + countryCode + " " + input.value;
            }
            input.style.backgroundImage = "url(https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/" + flagIcon.toLowerCase() + ".svg)";
            input.style.backgroundRepeat = "no-repeat";
            input.style.backgroundPosition = "5px center";
        }
    });
});
