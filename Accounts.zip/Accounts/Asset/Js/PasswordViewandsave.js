function togglePasswordVisibility() {
    var passwordField = document.querySelector('.password-field');
    var eyeIcon = document.querySelector('.eye-icon i');

    if (passwordField.type === "password") {
      passwordField.type = "text";
      eyeIcon.classList.remove('fa-eye-slash');
      eyeIcon.classList.add('fa-eye');
    } else {
      passwordField.type = "password";
      eyeIcon.classList.remove('fa-eye');
      eyeIcon.classList.add('fa-eye-slash');
    }
  }

  function rememberCredentials() {
    var emailField = document.querySelector('.email-field');
    var passwordField = document.querySelector('.password-field');
    var rememberCheckbox = document.getElementById('check1');

    if (rememberCheckbox.checked) {
      // Save the email and password (insecure, for demonstration purposes only)
      var email = emailField.value;
      var password = passwordField.value;
      localStorage.setItem('rememberedEmail', email);
      localStorage.setItem('rememberedPassword', password);
    } else {
      // Remove the saved email and password
      localStorage.removeItem('rememberedEmail');
      localStorage.removeItem('rememberedPassword');
    }
  }

  // Check if there are saved credentials on page load
  window.onload = function() {
    var rememberedEmail = localStorage.getItem('rememberedEmail');
    var rememberedPassword = localStorage.getItem('rememberedPassword');
    if (rememberedEmail && rememberedPassword) {
      document.querySelector('.email-field').value = rememberedEmail;
      document.querySelector('.password-field').value = rememberedPassword;
      document.getElementById('check1').checked = true;
    }
  };