
function toggleSidebar() {
    var sidebar = $("#top-sidebar");
    sidebar.toggleClass("active");
}
$(document).ready(function(){
 

    $('.open-submenu').click(function(){
        var subMenu = $(this).siblings('.sub_menu');
        $('.sub_menu').not(subMenu).slideUp();
        subMenu.slideToggle();
        $(this).toggleClass('rotate'); // Toggle rotation class
    });
});