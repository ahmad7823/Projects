
  // Function to get user location and set the embed link
  function getUserLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(successCallback, errorCallback);
    } else {
      alert("Geolocation is not supported by this browser.");
    }
  }

  // Success callback for geolocation
  function successCallback(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    
    // Set the obtained location in the hidden input field
    const embedLink = `https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d13462.170217082825!2d${longitude}!3d${latitude}!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1685545248457!5m2!1sen!2s`;
    
    document.getElementById("locationInput").value = embedLink;
  }

  // Error callback for geolocation
  function errorCallback(error) {
    console.error("Error getting location: ", error.message);
  }

  // Call the function when the page is loaded
  document.addEventListener("DOMContentLoaded", function () {
    getUserLocation();
  });


