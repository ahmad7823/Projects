$(document).ready(function(){
  // Show notification menu when bell icon is clicked
  $('#bellIcon').click(function(){
      $('#notificationMenu').toggle();
      // Hide the form if it's currently visible
      $('#hideDiv').addClass('hide');
      $('#showDiv').removeClass('show');
  });

  // Hide notification menu when clicking outside of it
  $(document).click(function(event) {
      if (!$(event.target).closest('#notificationMenu, #bellIcon').length) {
          $('#notificationMenu').hide();
      }
  });

  // Show/hide form when #showIcon is clicked
  $('#showIcon').click(function() {
      var hideDiv = $('#hideDiv');
      var showDiv = $('#showDiv');
      if (hideDiv.hasClass('hide')) {
          hideDiv.removeClass('hide');
          showDiv.addClass('show');
      } else {
          hideDiv.addClass('hide');
          showDiv.removeClass('show');
      }
      // Close notification menu if it's open
      $('#notificationMenu').hide();
  });

  // Close the form when the close button is clicked
  $('#closeBtn').click(function() {
      var showDiv = $('#showDiv');
      showDiv.removeClass('show');
      showDiv.addClass('hide');
  });
});