// JavaScript code to toggle visibility and rotate the icon
document.getElementById('show').addEventListener('click', function() {
  var show1 = document.getElementById('show1');
  var icon = document.querySelector('#show i');

  if (show1.style.display === 'none' || show1.style.display === '') {
    show1.style.display = 'block';
    icon.classList.add('rotate-icon');
  } else {
    show1.style.display = 'none';
    icon.classList.remove('rotate-icon');
  }
});