<?php
// Database connection details
// include 'Connection/connect.php';
// session_start();
// Retrieve the email and new password from the form

session_start();
include 'Connection/connect.php';

// Attempt to open connection
$conn = OpenConnection();

$UserPassword = $_POST['UserPassword'];
$OTP = $_POST['OTP'];

// Open the database connection
// $conn = OpenConnection();

// Check if the connection is successful
if ($conn) {
    // Update the user's password
    $sql = "UPDATE Users SET UserPassword = ? WHERE OTP = ?";
    $params = array($UserPassword, $OTP);
    $stmt = sqlsrv_prepare($conn, $sql, $params);
    
    // Check if the prepare statement is successful
    if ($stmt) {
        if (sqlsrv_execute($stmt)) {
            $rowsAffected = sqlsrv_rows_affected($stmt);
            if ($rowsAffected > 0) {
                $_SESSION['status'] = 'Successful Reset Password';
                header("Location: Index.php");
                exit();
            } else {
                $_SESSION['status'] = 'Password reset failed. Please try again.';
                header("Location: verify_otp.php");
                exit();
            }
        } else {
            $_SESSION['status'] = 'Error executing SQL statement: ' . print_r(sqlsrv_errors(), true);
            header("Location: verify_otp.php");
            exit();
        }
    } else {
        $_SESSION['status'] = 'Prepare statement failed.';
        header("Location: verify_otp.php");
        exit();
    }

    // Close the database connection
    sqlsrv_close($conn);
} else {
    $_SESSION['status'] = 'Failed to connect to the database.';
    header("Location: verify_otp.php");
    exit();
}
?>
