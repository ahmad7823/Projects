<?php
session_start();
include 'Connection/connect.php';

// Attempt to open connection
$conn = OpenConnection();

// Check if connection is successful and display data
if ($conn) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $UserName = $_POST['UserName'];
        $UserPassword = $_POST['UserPassword'];
        
        // SQL query with parameters to prevent SQL injection
        $sql = "SELECT * FROM Users WHERE UserName = ? ";
        $params = array($UserName);
        $stmt = sqlsrv_query($conn, $sql, $params);

        if ($stmt === false) {
            die(print_r(sqlsrv_errors(), true)); // Error handling
        }

        if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            // Verify password using password_verify if you are storing hashed passwords
            if ($row["UserPassword"] === $UserPassword) {
                $_SESSION["UserName"] = $UserName;
                $_SESSION["UserPassword"] = $UserPassword;
                $_SESSION['status'] = "Successfully logged in.";
                // Redirect to the admin page or any other page after successful login
                echo "<script> window.location.assign('Admin/ViewPayment.php');</script>";
                exit();
            } else {
                $_SESSION['status'] = "Wrong Username & Password Combination!";
                echo "<script> window.location.assign('index.php');</script>";
              
            }
        } else {
            $_SESSION['status'] = "User Not Exixts!";
            echo "<script> window.location.assign('index.php');</script>";
          
        }
    }
    sqlsrv_close($conn);
}
?>
