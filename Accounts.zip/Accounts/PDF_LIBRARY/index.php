<?php
require 'vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Create an instance of Dompdf
$options = new Options();
$options->set('isHtml5ParserEnabled', true); // Enable HTML5 parser
$dompdf = new Dompdf($options);

// Load HTML content with internal CSS
$html = '
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Document</title>
<style>
  .heading {
    background-color: #007bff;
    color: #fff;
    text-align: center;
  }
  .content {
    font-size: 18px;
    margin-top: 20px;
  }
</style>
</head>
<body>
<div class="heading">
  <h1>Hello, World!</h1>
</div>
<div class="content">
  <p>This is a sample PDF document generated using Dompdf with internal CSS.</p>
</div>
</body>
</html>';

// Load HTML content into Dompdf
$dompdf->loadHtml($html);

// Set paper size and orientation (optional)
$dompdf->setPaper('A4', 'portrait');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF (inline or as a file download)
$dompdf->stream('sample.pdf', array('Attachment' => false));
?>
