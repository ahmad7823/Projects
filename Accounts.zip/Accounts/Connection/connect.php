
<?php
// connect.php

function OpenConnection() {
    $serverName = "DESKTOP-FUGQNF4\\MSSQLSERVER2014"; // Note: Double backslash \\ for PHP strings

    $connectionOptions = array(
        "Database" => "Accounts",
        "Uid" => "sa",           // Use correct username
        "PWD" => "12345",        // Use correct password
        "Encrypt" => false,      // Disable encryption for local dev
        "TrustServerCertificate" => true // Must be true when Encrypt is false
    );

    // Attempt connection
    $conn = sqlsrv_connect($serverName, $connectionOptions);

    if ($conn === false) {
        echo "❌ SQL Server Connection Failed:<br>";
        die(print_r(sqlsrv_errors(), true));
    } else {
        echo "";
    }

    return $conn;
}

// Attempt to establish connection
OpenConnection();
?>
